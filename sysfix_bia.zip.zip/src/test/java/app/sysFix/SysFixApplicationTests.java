package app.sysFix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysFixApplicationTests {

	@Test
	void contextLoads() {
	}

}
