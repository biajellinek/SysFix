package app.sysFix.enums;

public enum StatusAtendimento {
	ATENDIDO,
	EM_ESPERA,
	SEM_ALOCACAO
	
}
