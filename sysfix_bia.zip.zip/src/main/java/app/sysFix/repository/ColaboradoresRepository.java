package app.sysFix.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import app.sysFix.entity.ColaboradoresEntity;

public interface ColaboradoresRepository extends JpaRepository<ColaboradoresEntity, Long>{

}
